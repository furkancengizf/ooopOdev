package Homework;

public class Category(int id , String name ){
  
  this.id = id;
  this.name = name;
  System.out.println("Kategori:" name "\nKategori Eklendi");
  
   int id;
   string name;
   
   }
   
}