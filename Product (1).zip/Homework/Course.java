package Homework;

public class Course(int id , String name , String instructor){
  this.id = id;
  this.name = name;
  this.instructor = instructor;

}
  int id;
  String name;
  String instructor;
  
}
 
 